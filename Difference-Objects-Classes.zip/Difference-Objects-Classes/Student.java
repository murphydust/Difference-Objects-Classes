/**
 * CLASS:
 * This is a class. Think of it as a blueprint.
 * It defines what a Student has (fields) and what a Student can do (methods).
 * By itself, this class is not a real student in memory.
 */
public class Student 
{

    // Fields (data)
    private String name;
    private int id;
    private double gpa;

    /**
     * Constructor:
     * Runs when a new Student object is created.
     */
    public Student(String name, int id, double gpa) 
    {
        this.name = name;
        this.id = id;
        this.gpa = gpa;
    }

    // Methods (behavior)
    public void printInfo() 
    {
        System.out.println("Student{name='" + name + "', id=" + id + ", gpa=" + gpa + "}");
    }

    public void study() 
    {
        System.out.println(name + " is studying.");
    }

    public double getGpa() 
    {
        return gpa;
    }

    public void setGpa(double newGpa) 
    {
        gpa = newGpa;
    }
}

/**
 * Demonstrates the difference between CLASSES and OBJECTS.
 */
public class Main 
{
    public static void main(String[] args) 
    {

        // OBJECTS:
        // These are real instances created from the Student class
        Student student1 = new Student("Dustin", 101, 3.5);
        Student student2 = new Student("Alex", 202, 2.9);

        System.out.println("----- Student Objects -----");
        student1.printInfo();
        student2.printInfo();

        System.out.println("\n----- Object Behavior -----");
        student1.study();
        student2.study();

        System.out.println("\n----- Independent Object Data -----");
        System.out.println("student1 GPA before: " + student1.getGpa());
        System.out.println("student2 GPA before: " + student2.getGpa());

        // Change one object
        student1.setGpa(3.9);

        System.out.println("student1 GPA after: " + student1.getGpa());
        System.out.println("student2 GPA after: " + student2.getGpa());

        System.out.println("\nStudent is the CLASS (blueprint).");
        System.out.println("student1 and student2 are OBJECTS created from that blueprint.");
    }
}
